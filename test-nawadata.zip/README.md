# Logic Test

## Developer's Profile
- Name : Rizky Putri Maharani
- Residence : Malang, Jawa Timur

## Result
- Directory : src/main/java/com/enigma/test_nawadata/Main.java
